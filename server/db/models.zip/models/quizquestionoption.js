import { Model } from "sequelize";
 
export default (sequelize, DataTypes) => {
  class QuizQuestionOption extends Model {
    static question;
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      this.belongsTo(models.QuizQuestion);
    }
  };

  QuizQuestionOption.init({
    value: DataTypes.STRING,
    text: DataTypes.STRING,
    sortOrder: DataTypes.INTEGER
  }, {
    defaultScope: {
      order: [['sortOrder', 'ASC']]
    },
    sequelize,
    modelName: 'quizQuestionOption',
  });

  return QuizQuestionOption;
};