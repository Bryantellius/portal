import { Model } from 'sequelize';
export default (sequelize, DataTypes) => {
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      this.belongsTo(models.Role);
      this.belongsToMany(models.Course, { through: models.CourseUser });
      this.hasMany(models.QuizSubmission);
      this.hasMany(models.ExerciseSubmission);
      this.hasMany(models.CourseUser);
    }

    static loadScopes (db) {
      this.addScope('defaultScope', {
        include: [
          {
            model: db.CourseUser,
            include: [
              {
                model: db.Course
              }
            ]
          },
          {
            model: db.QuizSubmission,
            include: [
              {
                model: db.QuizQuestionResponse,
                include: [
                  {
                    model: db.QuestionQuestion,
                    include: [
                      {
                        model: db.QuizQuestionOption
                      }
                    ]
                  }
                ]
              }
            ]
          },
          {
            model: db.ExerciseSubmission,
            include: [
              {
                model: db.Exercise,
                include: [
                  {
                    model: db.Video
                  }
                ]
              }
            ]
          }
        ],
        order: [
          [db.CourseUser, 'createdAt', 'DESC'],
          [db.quizQuestionResponses, 'createdAt', 'DESC'],
          [db.QuizSubmission, 'createdAt', 'DESC'],
          [db.ExerciseSubmission, 'createdAt', 'DESC'],
          [db.CourseUser, db.Course, db.Module, db.Lecture, db.Quiz, db.QuizQuestion, 'sortOrder', 'ASC'],
          [db.CourseUser, db.Course, db.Module, db.Lecture, db.Quiz, db.QuizQuestion, db.QuizQuestionOption,' sortOrder', 'ASC'],
          [db.CourseUser, db.Course, db.CourseModule, 'sortOrder', 'ASC']
        ]
      })
    }
  };
  User.init({
    firstName: DataTypes.STRING,
    lastName: DataTypes.STRING,
    email: DataTypes.STRING,
    password: DataTypes.STRING,
    auth0Id: DataTypes.STRING,
    avatarUrl: DataTypes.STRING,
    lastLectureId: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'user',
  });
  return User;
};