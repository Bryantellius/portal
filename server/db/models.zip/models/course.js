export default (sequelize, DataTypes) => {
  class Course extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      this.belongsToMany(models.User, { through: models.CourseUser });
      this.belongsToMany(models.Module, { through: models.CourseModule });
    }

    static loadScopes(models) {
      this.addScope('defaultScope', {
        include: [
          {
            model: models.Module,
            order: [
              [models.Course, models.Module, 'id', 'ASC'],
              [models.Course, models.Module, models.Lecture, 'id', 'ASC'],
              [models.Course, models.Module, models.Lecture, models.Quiz, models.QuizQuestion, 'sortOrder', 'ASC'],
              [models.Course, models.Module, models.Lecture, models.Quiz, models.QuizQuestion, models.QuizQuestionOption, 'sortOrder', 'ASC']
            ],
            include: [
              {
                model: models.Module,
                include: {
                  model: models.Lecture,
                  include: [
                    {
                      model: models.Exercise,
                      include: [
                        {
                          model: models.Video
                        }
  };


  Course.init({
    instructorId: DataTypes.INTEGER,
    title: DataTypes.STRING,
    description: DataTypes.TEXT,
    type: DataTypes.STRING,
    startDate: DataTypes.DATE,
    endDate: DataTypes.DATE,
    currentlyActive: DataTypes.BOOLEAN,
    avatarUrl: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'course',
  });
  return Course;
};